/**
 * @file course.c
 * @author Hakim Temacini (temacinh@mcmaster.ca)
 * @brief Course structure and the implementation for all the helper functions
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief A function for enrolling a student into a course by adding the student into the 
 * dynamic array for the course
 * 
 * @param course Specific course
 * @param student Student to add to the course
 */
void enroll_student(Course *course, Student *student)
{
  //If the number of students is one, simply allocate the amount of space needed for a student
  //Otherwise reallocate the memory to hold one more person
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Function for printing all the information about a course
 * 
 * @param course Course to print all the information from
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //Loop through all the students and print their information
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Function for finding the top student of the class i.e the student with the 
 * highest grade
 * 
 * @param course Course to find the best student in
 * @return Student* The best student in the course 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  // Loop through all the students and find the highest graded student
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Function for finding the number of students in a desired course, storing it in
 * the desired variable and returning the list of students that are passing the course
 * 
 * @param course Course to categorize all the students that are passing
 * @param total_passing Variable to store the number of students passing the course in
 * @return Student* Dynamic array of passing students
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //Make a new list to store only the passing students
  passing = calloc(count, sizeof(Student));

  // Loop through all the students and if they pass add them to the dynamic array
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}